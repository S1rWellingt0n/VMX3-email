import json
import os
import logging
import boto3
from botocore.exceptions import ClientError

# Initialize AWS clients
ses_client = boto3.client('ses', region_name='us-east-1')
s3_client = boto3.client('s3')
connect_client = boto3.client('connect')

# Email and Connect settings from environment variables
sender_email = os.getenv('SENDER_EMAIL')
recipient_email = os.getenv('RECIPIENT_EMAIL')
instance_id = os.getenv('CONNECT_INSTANCE_ID')

# Establish logging configuration
logger = logging.getLogger()
logger.setLevel(logging.getLevelName(os.getenv('lambda_logging_level', 'DEBUG')))

def lambda_handler(event, context):
    # Extract keys and buckets from the event and environment
    transcript_key = event['detail']['object']['key']
    transcript_bucket = os.getenv('s3_transcripts_bucket')
    contact_id = transcript_key.split('_')[0]
    recording_key = contact_id + '.wav'
    recording_bucket = os.getenv('s3_recordings_bucket')

    # Fetch contact attributes from Amazon Connect
    try:
        contact_attributes_response = connect_client.get_contact_attributes(
            InstanceId=instance_id,
            InitialContactId=contact_id
        )
        contact_attributes = contact_attributes_response['Attributes']
        caller_number = contact_attributes.get('vmx3_from', 'Unknown Caller')
        subject = f"Voicemail from {caller_number}"
    except ClientError as e:
        logger.error("Failed to fetch contact attributes: %s", e)
        caller_number = 'Unknown Caller'
        subject = f"Voicemail from {caller_number}"
    except Exception as e:
        logger.error("An error occurred while fetching contact attributes: %s", str(e))
        caller_number = 'Unknown Caller'
        subject = f"Voicemail from {caller_number}"

    # Generate presigned URL for the audio file
    try:
        audio_file_url = s3_client.generate_presigned_url('get_object',
                                                          Params={'Bucket': recording_bucket,
                                                                  'Key': recording_key},
                                                          ExpiresIn=604800)  # 7 days validity
    except ClientError as e:
        logger.error("Failed to generate presigned URL for audio file: %s", e)
        audio_file_url = 'No audio file available'

    # Download the transcription file from S3 and extract transcript
    try:
        transcript_file = s3_client.get_object(Bucket=transcript_bucket, Key=transcript_key)
        transcript_data = json.loads(transcript_file['Body'].read().decode('utf-8'))
        transcript_text = transcript_data['results']['transcripts'][0]['transcript']
    except ClientError as e:
        logger.error("Failed to download or parse transcript: %s", e)
        return {'status': 'fail', 'reason': 'Failed to download or parse transcript'}
    except KeyError as e:
        logger.error("Transcript data is malformed: %s", str(e))
        return {'status': 'fail', 'reason': 'Transcript data is malformed'}
    except Exception as e:
        logger.error("An unexpected error occurred: %s", str(e))
        return {'status': 'fail', 'reason': str(e)}

    # Prepare the email body with the transcript and audio file URL
    email_body = (f"Voicemail Transcript:\n\n{transcript_text}\n\n"
                  f"Audio File URL: {audio_file_url}")

    # Send email with the details
    try:
        response = ses_client.send_email(
            Source=sender_email,
            Destination={'ToAddresses': [recipient_email]},
            Message={
                'Subject': {'Data': subject, 'Charset': 'UTF-8'},
                'Body': {'Text': {'Data': email_body, 'Charset': 'UTF-8'}}
            }
        )
        logger.info("Email sent! Message ID: %s", response['MessageId'])
        return {'status': 'success', 'message_id': response['MessageId']}
    except ClientError as e:
        logger.error("An email error occurred: %s", e.response['Error']['Message'])
        return {'status': 'fail', 'reason': e.response['Error']['Message']}
    except Exception as e:
        logger.error("An error occurred: %s", str(e))
        return {'status': 'fail', 'reason': str(e)}

